#include "library3.h"

#include <vector>

void solve(int N) {
  std::vector<int> b(N, 0);
  for (int i = 0; i < N; i++) {
    b[i] = i;
  }
  int ret = 0;
  ret = query(b);
  answer(b);
}
