#!/bin/bash
g++ -std=gnu++20 -O2 -o grader grader.cpp library3.cpp
