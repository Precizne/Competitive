#include <vector>

void solve(int N);

int query(std::vector<int> a);
void answer(std::vector<int> b);
